// pages/indexx/indexx.js

// js
const app = getApp()
Page({
  data: {
    listData: [
      '我是内容一',
      '我是内容二',
      '我是内容三',
      '我是内容四',
      '我是内容五',
      '我是内容六',
      '我是内容七',
      '我是内容八'
    ],
    activeIndex: -1,
    list_style: '',
    startX: 0,
    rate: 2
  },
  onLoad() {
    let rate = 750 / wx.getSystemInfoSync().screenWidth
    this.setData({
      rate: rate
    })
  },
  touchstart: function (e) {
    let startX = e.touches[0].clientX
    this.setData({
      startX: startX
    })
  },
  touchmove: function (e) {
    let moveX = e.touches[0].clientX
    let dis = (this.data.startX - moveX) * this.data.rate // 换算成rpx
    let activeIndex = e.currentTarget.dataset.index
    let left = 240
    if (dis <= 0) {
      left = 240
    } else if (dis >= 240) {
      left = 0
    } else {
      left = 240 - dis
    }
    this.setData({
      list_style: 'transform:translateX(' + left + 'rpx)',
      activeIndex: activeIndex
    })
  },
  touchend: function (e) {
    let endX = e.changedTouches[0].clientX
    let dis = (this.data.startX - endX) * this.data.rate
    let activeIndex = e.currentTarget.dataset.index
    let left = 0
    if (dis >= 200) {
      left = 0
    } else {
      left = 240
    }
    this.setData({
      activeIndex: activeIndex,
      list_style: 'transform:translateX(' + left + 'rpx)'
    })
  },
  delete: function () {
    this.data.listData.splice(this.data.activeIndex, 1)
    this.setData({
      listData: this.data.listData
    })
  }
})